﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using TestApplications.Models;
using System.Web.Mvc.Html;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;

namespace TestApplications.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        [HttpGet]
        public ActionResult emp()
        {
           
            return View();
        }
  
        public ActionResult emps(int id)
        {
            EmployeeData employee = null;
            EmployeeDatalist employees = null;
            decimal avgsal = 0;
            decimal avgage = 0;
            try
            {
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://dummy.restapiexample.com/api/v1/");
                    //HTTP GET
                    var responseTask = client.GetAsync("employees");
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {

                        var jsonString = result.Content.ReadAsStringAsync();
                        jsonString.Wait();
                      employees = JsonConvert.DeserializeObject<EmployeeDatalist>(jsonString.Result);
                         avgsal = employees.data.Select(x => x.employee_salary).Average();
                          avgage= Convert.ToDecimal(employees.data.Select(x => x.employee_age).Average());
                        // employee= JsonConvert.DeserializeObject<employee>(data.data);
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        //employee = Enumerable.Empty<EmployeeData>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri("http://dummy.restapiexample.com/api/v1/");
                    //HTTP GET
                    var responseTask = client.GetAsync("employee/" + id);
                    responseTask.Wait();

                    var result = responseTask.Result;
                    if (result.IsSuccessStatusCode)
                    {
                        
                        var jsonString = result.Content.ReadAsStringAsync();
                        jsonString.Wait();
                      employee = JsonConvert.DeserializeObject<EmployeeData>(jsonString.Result);
                        employee.avgage = avgage;
                        employee.avgsal = avgsal;
                       // employee= JsonConvert.DeserializeObject<employee>(data.data);
                    }
                    else //web api sent error response 
                    {
                        //log response status here..

                        //employee = Enumerable.Empty<EmployeeData>();

                        ModelState.AddModelError(string.Empty, "Server error. Please contact administrator.");
                    }
                }
            }
            catch(AggregateException ex)
            { 
}
            return PartialView("employeedetails", employee);
        }
    }
}